const db = require("../config/db")
const { success, error } = require("../utils/response")

// GET ALL TRANSAKSI (JOIN elpiji)
exports.getAll = async (req, res) => {
  const search = req.query.search || ""

  const whereClause = search
    ? `WHERE e.pangkalan LIKE ? 
        OR e.pemilik LIKE ? 
        OR t.nama_driver LIKE ? 
        OR t.status LIKE ?`
    : ""

  const searchParams = search
    ? [`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`]
    : []

  const [rows] = await db.query(
    `
    SELECT 
      t.*,
      e.pangkalan,
      e.pemilik
    FROM transaksi t
    JOIN elpiji e ON e.id = t.elpiji_id
    ${whereClause}
    ORDER BY t.tanggal DESC, t.created_at DESC
    `,
    searchParams
  )

  return success(res, { data: rows })
}

// CREATE TRANSAKSI
exports.create = async (req, res) => {
  const {
    elpiji_id,
    nama_driver,
    tanggal,
    lpg_3kg,
    lpg_12kg,
    status,
  } = req.body

  if (!elpiji_id || !nama_driver || !tanggal || !status) {
    return error(res, "Data wajib belum lengkap")
  }

  await db.query(
    `
    INSERT INTO transaksi
    (elpiji_id, nama_driver, tanggal, lpg_3kg, lpg_12kg, status)
    VALUES (?, ?, ?, ?, ?, ?)
    `,
    [
      elpiji_id,
      nama_driver,
      tanggal,
      lpg_3kg || 0,
      lpg_12kg || 0,
      status,
    ]
  )

  return success(res, null, "Transaksi berhasil ditambahkan")
}

// UPDATE TRANSAKSI
exports.update = async (req, res) => {
  const { id } = req.params

  const {
    elpiji_id,
    nama_driver,
    tanggal,
    lpg_3kg,
    lpg_12kg,
    status,
  } = req.body

  await db.query(
    `
    UPDATE transaksi
    SET 
      elpiji_id = ?,
      nama_driver = ?,
      tanggal = ?,
      lpg_3kg = ?,
      lpg_12kg = ?,
      status = ?
    WHERE id = ?
    `,
    [
      elpiji_id,
      nama_driver,
      tanggal,
      lpg_3kg,
      lpg_12kg,
      status,
      id,
    ]
  )

  return success(res, null, "Transaksi berhasil diperbarui")
}

// DELETE TRANSAKSI
exports.remove = async (req, res) => {
  await db.query("DELETE FROM transaksi WHERE id = ?", [req.params.id])
  return success(res, null, "Transaksi berhasil dihapus")
}
