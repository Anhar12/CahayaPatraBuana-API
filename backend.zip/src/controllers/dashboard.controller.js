const db = require("../config/db")
const { success } = require("../utils/response")

exports.stats = async (req, res) => {
  const [[stats]] = await db.query(`
    SELECT * FROM storage;
  `)

  return success(res, stats)
}
